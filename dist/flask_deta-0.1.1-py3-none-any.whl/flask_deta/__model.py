# Under construction
class DetaModel:
    pass
