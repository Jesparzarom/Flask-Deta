document$.subscribe(() => {
    hljs.highlightAll()
})
  